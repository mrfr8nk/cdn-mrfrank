/**
 * ╔══════════════════════════════════════════╗
 * ║   FUNDO AI — MongoDB + Plan System        ║
 * ╚══════════════════════════════════════════╝
 */

import mongoose from 'mongoose';

// ─── Connection ────────────────────────────────────────────────────────────────
const MONGO_URI = process.env.MONGO_URI || 'mongodb+srv://darexmucheri:cMd7EoTwGglJGXwR@cluster0.uwf6z.mongodb.net/fun?retryWrites=true&w=majority&appName=Cluster0';
let dbReady = false;

export async function connectDB() {
  if (!MONGO_URI) { console.warn('⚠️  MONGO_URI not set — plan system disabled'); return; }
  try {
    await mongoose.connect(MONGO_URI, { serverSelectionTimeoutMS: 10000 });
    dbReady = true;
    console.log('✅  MongoDB connected — plan system active');
  } catch (e) {
    console.warn('⚠️  MongoDB connect failed:', e.message?.substring(0, 100));
  }
}
export const isDbReady = () => dbReady;

// ─── Plan definitions ──────────────────────────────────────────────────────────
export const PLANS = {
  FREE:    { label: 'Free',    chat: 25,       chatPeriod: 'day',   images: 3,        imagesPeriod: 'day',   pdf: 1,        pdfPeriod: 'day',   price: 0,  mock: 3,        voice: 10,       voicePeriod: 'day',   duration: 30 },
  STARTER: { label: 'Starter', chat: 2000,     chatPeriod: 'month', images: 200,      imagesPeriod: 'month', pdf: 3,        pdfPeriod: 'month', price: 1,  mock: 10,       voice: 50,       voicePeriod: 'day',   duration: 30 },
  BASIC:   { label: 'Basic',   chat: 9000,     chatPeriod: 'month', images: 600,      imagesPeriod: 'month', pdf: 10,       pdfPeriod: 'month', price: 3,  mock: 20,       voice: 100,      voicePeriod: 'day',   duration: 30 },
  PRO:     { label: 'Pro',     chat: 30000,    chatPeriod: 'month', images: 1500,     imagesPeriod: 'month', pdf: 50,       pdfPeriod: 'month', price: 10, mock: 50,       voice: 300,      voicePeriod: 'day',   duration: 30 },
  PREMIUM: { label: 'Premium', chat: Infinity, chatPeriod: 'month', images: Infinity, imagesPeriod: 'month', pdf: Infinity, pdfPeriod: 'month', price: 20, mock: Infinity, voice: Infinity, voicePeriod: 'day',   duration: 30 },
};
export const PLAN_CREDITS = { FREE: 0, STARTER: 200, BASIC: 1000, PRO: 5000, PREMIUM: 20000 };

// ─── Helpers ───────────────────────────────────────────────────────────────────
const todayStr = () => new Date().toISOString().slice(0, 10);   // YYYY-MM-DD
const monthStr = () => new Date().toISOString().slice(0, 7);    // YYYY-MM

// ─── User schema ───────────────────────────────────────────────────────────────
const userSchema = new mongoose.Schema({
  phone:         { type: String, required: true, unique: true, index: true },
  plan:          { type: String, default: 'FREE', enum: ['FREE', 'STARTER', 'BASIC', 'PRO', 'PREMIUM'] },
  credits:       { type: Number, default: 0 },
  uploadCount:   { type: Number, default: 0 },
  extraProjects: { type: Number, default: 0 },
  extraMessages: { type: Number, default: 0 },
  extraImages:   { type: Number, default: 0 },
  // ── Profile fields ───────────────────────────────────────────────────────────
  name:          { type: String, default: '' },
  email:         { type: String, default: '' },
  age:           { type: String, default: '' },
  school:        { type: String, default: '' },
  levelType:     { type: String, default: '' },
  levelLabel:    { type: String, default: '' },
  grade:         { type: String, default: '' },
  // ── Onboarding flag ──────────────────────────────────────────────────────────
  welcomed:      { type: Boolean, default: false },
  // ── Referral system ──────────────────────────────────────────────────────────
  referralCode:  { type: String, default: '', index: true },
  referredBy:    { type: String, default: '' },
  referralCount: { type: Number, default: 0 },
  referredUsers: { type: [String], default: [] },
  // ── Limit exhaustion timestamps (ms since epoch, 0 = not hit today) ─────────
  exhaustedChatAt:  { type: Number, default: 0 },
  exhaustedImageAt: { type: Number, default: 0 },
  exhaustedPdfAt:   { type: Number, default: 0 },
  // ── Pending referral code (persists across restarts) ─────────────────────────
  pendingReferral:  { type: String, default: '' },
  planActivatedAt:   { type: Date, default: null },
  planExpiresAt:     { type: Date, default: null },
  nextMonthResetAt:  { type: Number, default: 0 }, // ms epoch of next 30-day usage reset
  // ── Engagement tracking ───────────────────────────────────────────────────────
  lastActiveAt:    { type: Number, default: 0 },  // ms epoch of last message
  lastReengageAt:  { type: Number, default: 0 },  // ms epoch of last re-engagement send
  usage: {
    chatToday:        { type: Number, default: 0 },
    chatMonth:        { type: Number, default: 0 },
    imagesToday:      { type: Number, default: 0 },
    imagesMonth:      { type: Number, default: 0 },
    pdfToday:         { type: Number, default: 0 },
    pdfMonth:         { type: Number, default: 0 },
    voiceToday:       { type: Number, default: 0 },
    mediaDownloads:    { type: Number, default: 0 },
    mockMonth:         { type: Number, default: 0 },
    lastDayReset:      { type: String, default: '' },
    lastMonthReset:    { type: String, default: '' },
    lastDownloadReset: { type: String, default: '' },
  },
}, { timestamps: true });

export const UserModel = mongoose.models.User || mongoose.model('User', userSchema);

// ─── Payment schema ────────────────────────────────────────────────────────────
const paymentSchema = new mongoose.Schema({
  phone:     { type: String, required: true },
  reference: { type: String, required: true, unique: true },
  plan:      { type: String, required: true },
  amount:    { type: Number, required: true },
  ecocash:   { type: String, default: '' },
  status:    { type: String, default: 'pending', enum: ['pending', 'paid', 'failed'] },
  pollUrl:   { type: String, default: '' },
}, { timestamps: true });

export const PaymentModel = mongoose.models.Payment || mongoose.model('Payment', paymentSchema);

// ─── App config schema (global flags, e.g. disable project 24-h wait) ─────────
const appConfigSchema = new mongoose.Schema({
  key:   { type: String, required: true, unique: true, index: true },
  value: { type: mongoose.Schema.Types.Mixed },
}, { timestamps: true });

export const AppConfigModel = mongoose.models.AppConfig || mongoose.model('AppConfig', appConfigSchema);

export async function getConfig(key, fallback = null) {
  if (!dbReady) return fallback;
  try {
    const doc = await AppConfigModel.findOne({ key });
    return doc ? doc.value : fallback;
  } catch (_) { return fallback; }
}

export async function setConfig(key, value) {
  if (!dbReady) return false;
  try {
    await AppConfigModel.findOneAndUpdate(
      { key },
      { key, value },
      { upsert: true, new: true }
    );
    return true;
  } catch (_) { return false; }
}

// ─── Material schema ───────────────────────────────────────────────────────────
const materialSchema = new mongoose.Schema({
  category:   { type: String, required: true, enum: ['syllabus', 'paper', 'textbook', 'marking_scheme'] },
  level:      { type: String, required: true }, // 'primary' | 'olevel' | 'alevel'
  grade:      { type: String, default: '' },    // 'Grade 7' | 'Form 4' | '' (for A-Level)
  subject:    { type: String, required: true },
  title:      { type: String, required: true },
  url:        { type: String, required: true },
  mimeType:   { type: String, default: 'application/pdf' },
  fileSize:   { type: Number, default: 0 },
  uploadedBy: { type: String, default: '' },    // phone number
  approved:   { type: Boolean, default: false },
  approvedBy: { type: String, default: '' },
}, { timestamps: true });

export const MaterialModel = mongoose.models.Material || mongoose.model('Material', materialSchema);

export async function getMaterials(category, level, grade, subject) {
  if (!dbReady) return [];
  try {
    const query = { approved: true, category, level };
    // Escape regex special chars so subject names with parens etc. don't break the query
    const escapedSubject = subject.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    // Match subject: "Physics" matches "Physics", "Physics (ZIMSEC)", "Physics (Cambridge)" etc.
    query.subject = new RegExp(escapedSubject, 'i');
    // For A-Level the bot stores grade='A-Level' but portal may store '' — skip grade filter
    // For Primary/O-Level, grade distinguishes Form 1 from Form 4 etc. so keep the filter
    if (grade && grade !== 'A-Level') query.grade = grade;
    return await MaterialModel.find(query).sort({ createdAt: -1 }).limit(50);
  } catch (e) { return []; }
}

export async function addMaterial(data) {
  if (!dbReady) return null;
  try { return await MaterialModel.create(data); } catch (e) { return null; }
}

export async function approveMaterial(id, approvedBy = '') {
  if (!dbReady) return false;
  try {
    const m = await MaterialModel.findByIdAndUpdate(id, { approved: true, approvedBy }, { new: false });
    if (m && m.uploadedBy) {
      const user = await UserModel.findOneAndUpdate(
        { phone: m.uploadedBy },
        { $inc: { uploadCount: 1 } },
        { upsert: true, new: true }
      );
      if (user && user.uploadCount % 3 === 0) {
        await UserModel.findOneAndUpdate({ phone: m.uploadedBy }, { $inc: { extraProjects: 1, extraMessages: 10, extraImages: 2 } });
      }
    }
    return !!m;
  } catch (e) { return false; }
}

export async function approveAllMaterials(approvedBy = '') {
  if (!dbReady) return { count: 0, uploaders: [] };
  try {
    const pending = await MaterialModel.find({ approved: false });
    if (!pending.length) return { count: 0, uploaders: [] };
    const uploaders = [];
    for (const m of pending) {
      await MaterialModel.findByIdAndUpdate(m._id, { approved: true, approvedBy });
      uploaders.push({ phone: m.uploadedBy || '', title: m.title, id: String(m._id), level: m.level, grade: m.grade, category: m.category, subject: m.subject });
      if (m.uploadedBy) {
        const user = await UserModel.findOneAndUpdate(
          { phone: m.uploadedBy },
          { $inc: { uploadCount: 1 } },
          { upsert: true, new: true }
        );
        if (user && user.uploadCount % 3 === 0) {
          await UserModel.findOneAndUpdate({ phone: m.uploadedBy }, { $inc: { extraProjects: 1, extraMessages: 10, extraImages: 2 } });
        }
      }
    }
    return { count: pending.length, uploaders };
  } catch (e) { return { count: 0, uploaders: [] }; }
}

export async function recordManualPayment(phone, plan) {
  if (!dbReady) return false;
  try {
    const ref = `MANUAL-${phone}-${Date.now()}`;
    await PaymentModel.create({ phone, reference: ref, plan, amount: PLANS[plan]?.price || 0, status: 'pending' }).catch(() => {});
    return true;
  } catch (_) { return false; }
}

export async function rejectMaterial(id) {
  if (!dbReady) return false;
  try { await MaterialModel.findByIdAndDelete(id); return true; } catch (e) { return false; }
}

export async function getPendingMaterials() {
  if (!dbReady) return [];
  try { return await MaterialModel.find({ approved: false }).sort({ createdAt: -1 }).limit(10); } catch (e) { return []; }
}

export async function getMaterialById(id) {
  if (!dbReady) return null;
  try { return await MaterialModel.findById(id); } catch (e) { return null; }
}

export async function listAllMaterials({ level, category, page = 0, pageSize = 10 } = {}) {
  if (!dbReady) return [];
  try {
    const query = { approved: true };
    if (level) query.level = level;
    if (category) query.category = category;
    return await MaterialModel.find(query).sort({ level: 1, category: 1, createdAt: -1 }).skip(page * pageSize).limit(pageSize);
  } catch (e) { return []; }
}

export async function countAllMaterials({ level, category } = {}) {
  if (!dbReady) return 0;
  try {
    const query = { approved: true };
    if (level) query.level = level;
    if (category) query.category = category;
    return await MaterialModel.countDocuments(query);
  } catch (e) { return 0; }
}

export async function deleteMaterialById(id) {
  if (!dbReady) return false;
  try { await MaterialModel.findByIdAndDelete(id); return true; } catch (e) { return false; }
}

export async function renameMaterialById(id, newTitle) {
  if (!dbReady) return false;
  try {
    const r = await MaterialModel.findByIdAndUpdate(id, { title: newTitle });
    return !!r;
  } catch (e) { return false; }
}

export async function getAllUserPhones() {
  if (!dbReady) return [];
  try { return (await UserModel.find({}, 'phone')).map(u => u.phone).filter(Boolean); } catch (e) { return []; }
}

export async function getAllUsersInfo({ limit = 0 } = {}) {
  if (!dbReady) return [];
  try {
    let q = UserModel.find({}, 'phone plan createdAt uploadCount referralCount').sort({ createdAt: -1 });
    if (limit > 0) q = q.limit(limit);
    return await q;
  } catch (e) { return []; }
}

export async function getAllUsersWithProfiles({ limit = 2000 } = {}) {
  if (!dbReady) return [];
  try {
    let q = UserModel.find(
      {},
      'phone name email age school levelType levelLabel grade plan createdAt uploadCount referralCount welcomed'
    ).sort({ createdAt: -1 });
    if (limit > 0) q = q.limit(limit);
    return await q.lean();
  } catch (e) { return []; }
}

export async function markUserWelcomed(phone) {
  if (!dbReady || !phone) return;
  await UserModel.findOneAndUpdate(
    { phone },
    { $set: { welcomed: true } },
    { upsert: true }
  ).catch(() => {});
}

// ─── Update lastActiveAt for a user whenever they message ─────────────────────
export async function updateLastActive(phone) {
  if (!dbReady || !phone) return;
  await UserModel.updateOne({ phone }, { $set: { lastActiveAt: Date.now() } }).catch(() => {});
}

// ─── Get users inactive for more than `days` days, not re-engaged recently ────
export async function getInactiveUsers(days = 3, reengageCooldownDays = 5) {
  if (!dbReady) return [];
  try {
    const cutoff        = Date.now() - days * 24 * 60 * 60 * 1000;
    const reengageCutoff = Date.now() - reengageCooldownDays * 24 * 60 * 60 * 1000;
    return await UserModel.find(
      {
        phone:        { $exists: true, $ne: '' },
        lastActiveAt: { $gt: 0, $lt: cutoff },          // active before, but not recently
        $or: [
          { lastReengageAt: { $exists: false } },
          { lastReengageAt: 0 },
          { lastReengageAt: { $lt: reengageCutoff } },  // cooldown: don't spam
        ],
      },
      'phone name levelLabel grade plan lastActiveAt'
    ).lean();
  } catch (e) { return []; }
}

// ─── Mark that a re-engagement message was sent to this user ──────────────────
export async function markReengaged(phone) {
  if (!dbReady || !phone) return;
  await UserModel.updateOne({ phone }, { $set: { lastReengageAt: Date.now() } }).catch(() => {});
}

export async function getUploaderStats(phone) {
  if (!dbReady) return { uploadCount: 0, extraProjects: 0 };
  try {
    const user = await UserModel.findOne({ phone });
    return { uploadCount: user?.uploadCount || 0, extraProjects: user?.extraProjects || 0 };
  } catch (e) { return { uploadCount: 0, extraProjects: 0 }; }
}

export async function useExtraProject(phone) {
  if (!dbReady) return false;
  try {
    const res = await UserModel.findOneAndUpdate(
      { phone, extraProjects: { $gt: 0 } },
      { $inc: { extraProjects: -1 } },
      { new: true }
    );
    return !!res;
  } catch (e) { return false; }
}

// ─── Media download limit (free users: 5/day) ─────────────────────────────────
export function checkDownloadLimit(user) {
  if (!user) return false;
  const p = PLANS[user.plan] || PLANS.FREE;
  if (p.price > 0) return false; // paid users: unlimited downloads
  return (user.usage.mediaDownloads || 0) >= 5;
}

export async function incrementDownload(user) {
  if (!user) return;
  user.usage.mediaDownloads = (user.usage.mediaDownloads || 0) + 1;
  await user.save().catch(() => {});
}

// ─── Get or create user ────────────────────────────────────────────────────────
export async function getUser(phone) {
  if (!dbReady) return null;
  try {
    return await UserModel.findOneAndUpdate(
      { phone },
      { $setOnInsert: { phone } },
      { upsert: true, new: true }
    );
  } catch (e) { console.warn('getUser err:', e.message?.substring(0, 60)); return null; }
}

// ─── Reset daily / monthly counters if needed ──────────────────────────────────
export async function resetUsageIfNeeded(user) {
  if (!user) return;
  const today = todayStr(), month = monthStr();
  const now   = Date.now();
  const p = PLANS[user.plan] || PLANS.FREE;
  const set = {};

  // ── Daily reset ────────────────────────────────────────────────────────────
  if (user.usage.lastDayReset !== today) {
    user.usage.chatToday      = 0;
    user.usage.imagesToday    = 0;
    user.usage.mediaDownloads = 0;
    if (user.plan === 'FREE') {
      user.usage.pdfToday = 0;
      user.exhaustedChatAt  = 0;
      user.exhaustedImageAt = 0;
      user.exhaustedPdfAt   = 0;
      set['exhaustedChatAt']  = 0;
      set['exhaustedImageAt'] = 0;
      set['exhaustedPdfAt']   = 0;
    }
    user.usage.lastDayReset      = today;
    user.usage.lastDownloadReset = today;
    set['usage.chatToday']        = 0;
    set['usage.imagesToday']      = 0;
    set['usage.mediaDownloads']   = 0;
    set['usage.lastDayReset']     = today;
    set['usage.lastDownloadReset']= today;
    if (user.plan === 'FREE') set['usage.pdfToday'] = 0;
  }

  // ── Monthly reset — 30-day rolling window from plan activation ─────────────
  // Determine the next reset timestamp for this user
  let nextReset = user.nextMonthResetAt || 0;
  if (!nextReset) {
    // Migrate: compute from planActivatedAt or fall back to calendar month
    if (user.planActivatedAt) {
      const activated = new Date(user.planActivatedAt).getTime();
      // Find next 30-day boundary from activation
      const elapsed = now - activated;
      const cycles  = Math.floor(elapsed / (30 * 24 * 3600 * 1000));
      nextReset = activated + (cycles + 1) * 30 * 24 * 3600 * 1000;
    } else {
      // No activation date — use end of current calendar month as first reset
      const nm = new Date(); nm.setMonth(nm.getMonth() + 1, 1); nm.setHours(0, 0, 0, 0);
      nextReset = nm.getTime();
    }
    user.nextMonthResetAt = nextReset;
    set['nextMonthResetAt'] = nextReset;
  }

  if (now >= nextReset) {
    // Advance nextReset by as many 30-day cycles as needed
    while (now >= nextReset) nextReset += 30 * 24 * 3600 * 1000;
    user.nextMonthResetAt      = nextReset;
    user.usage.pdfMonth        = 0;
    user.usage.mockMonth       = 0;
    user.usage.chatMonth       = 0;
    user.usage.imagesMonth     = 0;
    user.usage.lastMonthReset  = month; // keep for legacy compat
    set['nextMonthResetAt']    = nextReset;
    set['usage.pdfMonth']      = 0;
    set['usage.mockMonth']     = 0;
    set['usage.chatMonth']     = 0;
    set['usage.imagesMonth']   = 0;
    set['usage.lastMonthReset']= month;
    if (p.pdfPeriod === 'month') set['usage.pdfToday'] = 0;
    if (user.plan !== 'FREE') {
      user.exhaustedChatAt  = 0;
      user.exhaustedImageAt = 0;
      user.exhaustedPdfAt   = 0;
      set['exhaustedChatAt']  = 0;
      set['exhaustedImageAt'] = 0;
      set['exhaustedPdfAt']   = 0;
    }
  }

  if (Object.keys(set).length) {
    try { await UserModel.updateOne({ phone: user.phone }, { $set: set }); }
    catch (_) { try { user.markModified('usage'); await user.save(); } catch (_) {} }
  }
}

// ─── Check limit — returns plan name if exceeded, null if OK ──────────────────
export function checkLimit(user, type) {
  if (!user) return null;
  const p = PLANS[user.plan] || PLANS.FREE;
  const u = user.usage;
  if (type === 'chat') {
    const used = p.chatPeriod === 'month' ? (u.chatMonth || 0) : (u.chatToday || 0);
    if (used >= p.chat && (user.extraMessages || 0) <= 0) return user.plan;
  }
  if (type === 'image') {
    const used = p.imagesPeriod === 'month' ? (u.imagesMonth || 0) : (u.imagesToday || 0);
    if (used >= p.images && (user.extraImages || 0) <= 0) return user.plan;
  }
  if (type === 'pdf') {
    const used = p.pdfPeriod === 'day' ? u.pdfToday : u.pdfMonth;
    if (used >= p.pdf) return user.plan;
  }
  if (type === 'voice') {
    const used = u.voiceToday || 0;
    if (p.voice !== Infinity && used >= p.voice) return user.plan;
  }
  return null;
}

// ─── Get users matching a level/grade for notifications ───────────────────────
export async function getUsersByLevel(levelLabel, grade) {
  if (!dbReady) return [];
  try {
    const q = { phone: { $exists: true, $ne: '' } };
    if (levelLabel) q.levelLabel = levelLabel;
    if (grade)      q.grade = grade;
    const users = await UserModel.find(q, 'phone').lean();
    return users.map(u => u.phone).filter(Boolean);
  } catch (_) { return []; }
}

// ─── Increment usage counter (ATOMIC — prevents bypass under concurrent load) ─
export async function incrementUsage(user, type) {
  if (!user) return;
  const p = PLANS[user.plan] || PLANS.FREE;
  const inc = {};
  let useExtra = false;

  if (type === 'chat') {
    const chatUsed = p.chatPeriod === 'month' ? (user.usage.chatMonth || 0) : (user.usage.chatToday || 0);
    if (chatUsed >= p.chat && (user.extraMessages || 0) > 0) {
      inc.extraMessages = -1;
      useExtra = true;
    }
    inc['usage.chatToday']  = 1;
    inc['usage.chatMonth']  = 1;
    if (useExtra) user.extraMessages = Math.max(0, (user.extraMessages || 0) - 1);
    user.usage.chatToday  = (user.usage.chatToday || 0) + 1;
    user.usage.chatMonth  = (user.usage.chatMonth || 0) + 1;
  }
  if (type === 'image') {
    const imgUsed = p.imagesPeriod === 'month' ? (user.usage.imagesMonth || 0) : (user.usage.imagesToday || 0);
    if (imgUsed >= p.images && (user.extraImages || 0) > 0) {
      inc.extraImages = -1;
      useExtra = true;
    }
    inc['usage.imagesToday']  = 1;
    inc['usage.imagesMonth']  = 1;
    if (useExtra) user.extraImages = Math.max(0, (user.extraImages || 0) - 1);
    user.usage.imagesToday  = (user.usage.imagesToday || 0) + 1;
    user.usage.imagesMonth  = (user.usage.imagesMonth || 0) + 1;
  }
  if (type === 'pdf') {
    inc['usage.pdfToday'] = 1;
    inc['usage.pdfMonth'] = 1;
    user.usage.pdfToday = (user.usage.pdfToday || 0) + 1;
    user.usage.pdfMonth = (user.usage.pdfMonth || 0) + 1;
  }
  if (type === 'voice') {
    inc['usage.voiceToday'] = 1;
    user.usage.voiceToday = (user.usage.voiceToday || 0) + 1;
  }

  // Atomic DB update — guarantees the counter persists even if the in-memory
  // doc is stale or another concurrent handler holds a different copy.
  try {
    await UserModel.updateOne({ phone: user.phone }, { $inc: inc });
  } catch (_) {
    // Fall back to .save() with markModified so nested path is tracked
    try { user.markModified('usage'); await user.save(); } catch (_) {}
  }
}

// ─── Activate plan after payment ───────────────────────────────────────────────
export async function activatePlan(phone, plan) {
  if (!dbReady) return;
  const now = new Date();
  const duration = PLANS[plan]?.duration || 30;
  const expires = new Date(now.getTime() + duration * 24 * 60 * 60 * 1000);
  const nextMonthResetAt = now.getTime() + 30 * 24 * 60 * 60 * 1000;
  await UserModel.findOneAndUpdate(
    { phone },
    {
      plan,
      credits: PLAN_CREDITS[plan] || 0,
      exhaustedChatAt: 0,
      exhaustedImageAt: 0,
      planActivatedAt: now,
      planExpiresAt: expires,
      nextMonthResetAt,
      'usage.chatToday': 0,
      'usage.chatMonth': 0,
      'usage.imagesToday': 0,
      'usage.imagesMonth': 0,
      'usage.mockMonth': 0,
      'usage.pdfMonth': 0,
    },
    { upsert: true }
  ).catch(() => {});
  await PaymentModel.findOneAndUpdate(
    { phone, status: 'pending' },
    { status: 'paid' }
  ).catch(() => {});
}

// ─── Initiate Paynow EcoCash push payment ──────────────────────────────────────
export async function initiatePaynow(phone, plan, ecocash) {
  const ID  = process.env.PAYNOW_ID  || '';
  const KEY = process.env.PAYNOW_KEY || '';
  if (!ID || !KEY) return { ok: false, error: 'Paynow credentials not configured' };

  try {
    const { Paynow } = await import('paynow');
    const pn = new Paynow(ID, KEY);
    pn.resultUrl = 'https://fundoai.synapex.co.zw/paynow/result';
    pn.returnUrl = 'https://fundoai.synapex.co.zw/paynow/return';

    const amount = PLANS[plan]?.price ?? 0;
    const ref    = `FUNDO-${phone}-${Date.now()}`;
    const pmt    = pn.createPayment(ref, `${ecocash}@ecocash.co.zw`);
    pmt.add(`Fundo AI ${PLANS[plan]?.label ?? plan} Plan`, amount);

    const resp = await pn.sendMobile(pmt, ecocash, 'ecocash');
    if (resp.success) {
      await PaymentModel.create({ phone, reference: ref, plan, amount, ecocash, pollUrl: resp.pollUrl }).catch(() => {});
      return { ok: true, pollUrl: resp.pollUrl, reference: ref };
    }
    return { ok: false, error: resp.error || 'Paynow rejected the request' };
  } catch (e) {
    return { ok: false, error: e.message?.substring(0, 100) };
  }
}

// ─── Poll a Paynow transaction ─────────────────────────────────────────────────
export async function pollPaynow(pollUrl) {
  const ID  = process.env.PAYNOW_ID  || '';
  const KEY = process.env.PAYNOW_KEY || '';
  if (!ID || !KEY || !pollUrl) return 'unknown';
  try {
    const { Paynow } = await import('paynow');
    const pn = new Paynow(ID, KEY);
    const st = await pn.pollTransaction(pollUrl);
    return (st.status || 'unknown').toLowerCase();
  } catch (_) { return 'unknown'; }
}

// ─── Profile DB helpers ────────────────────────────────────────────────────────
export async function updateUserProfile(phone, data) {
  if (!dbReady || !phone) return;
  const allowed = ['name', 'email', 'age', 'school', 'levelType', 'levelLabel', 'grade'];
  const update  = {};
  for (const k of allowed) if (data[k] !== undefined && data[k] !== null) update[k] = String(data[k]);
  if (!Object.keys(update).length) return;
  await UserModel.findOneAndUpdate({ phone }, { $set: update }, { upsert: true }).catch(() => {});
}

export async function getUserProfile(phone) {
  if (!dbReady || !phone) return null;
  try {
    return await UserModel.findOne({ phone })
      .select('name email age school levelType levelLabel grade plan referralCode referralCount uploadCount createdAt')
      .lean();
  } catch (_) { return null; }
}

// ─── Referral system ───────────────────────────────────────────────────────────
function makeReferralCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = 'REF-';
  for (let i = 0; i < 6; i++) code += chars[Math.floor(Math.random() * chars.length)];
  return code;
}

export async function generateReferralCode(phone) {
  if (!dbReady) return null;
  try {
    const user = await UserModel.findOne({ phone });
    if (!user) return null;
    if (user.referralCode) return user.referralCode;
    let code, exists;
    do {
      code = makeReferralCode();
      exists = await UserModel.findOne({ referralCode: code });
    } while (exists);
    await UserModel.updateOne({ phone }, { $set: { referralCode: code } });
    return code;
  } catch (e) { return null; }
}

export async function processReferral(newPhone, referralCode) {
  if (!dbReady) return { ok: false, reason: 'db_off' };
  try {
    const code = (referralCode || '').trim().toUpperCase();
    const referrer = await UserModel.findOne({ referralCode: code });
    if (!referrer) return { ok: false, reason: 'invalid_code' };
    if (referrer.phone === newPhone) return { ok: false, reason: 'self_referral' };
    if (referrer.referredUsers.includes(newPhone)) return { ok: false, reason: 'already_referred' };
    const newUser = await UserModel.findOne({ phone: newPhone });
    if (newUser?.referredBy) return { ok: false, reason: 'already_referred' };
    // Reward referrer: +5 messages, +2 images, +1 project
    await UserModel.updateOne(
      { phone: referrer.phone },
      { $inc: { referralCount: 1, extraMessages: 5, extraImages: 2, extraProjects: 1 }, $push: { referredUsers: newPhone } }
    );
    // Mark new user as referred
    await UserModel.findOneAndUpdate(
      { phone: newPhone },
      { $set: { referredBy: referrer.phone } },
      { upsert: true }
    );
    return { ok: true, referrerPhone: referrer.phone };
  } catch (e) { return { ok: false, reason: 'error' }; }
}

export function checkMockLimit(user) {
  if (!user) return false;
  const p = PLANS[user.plan] || PLANS.FREE;
  if (p.mock === Infinity) return false;
  return (user.usage.mockMonth || 0) >= p.mock;
}

export async function incrementMockUsage(user) {
  if (!user) return;
  user.usage.mockMonth = (user.usage.mockMonth || 0) + 1;
  try { await UserModel.updateOne({ phone: user.phone }, { $inc: { 'usage.mockMonth': 1 } }); }
  catch (_) { try { user.markModified('usage'); await user.save(); } catch (_) {} }
}

export async function validateReferralCode(code) {
  if (!dbReady || !code) return null;
  try {
    const referrer = await UserModel.findOne({ referralCode: code.trim().toUpperCase() });
    return referrer ? referrer.phone : null;
  } catch (_) { return null; }
}

export async function deleteLidUsers() {
  if (!dbReady) return { deleted: 0 };
  try {
    // Lid phones are longer than 15 digits — they are fake/internal WhatsApp IDs
    const all = await UserModel.find({}, 'phone').lean();
    const lidPhones = all.map(u => u.phone).filter(p => p && p.replace(/\D/g,'').length > 15);
    if (!lidPhones.length) return { deleted: 0 };
    const result = await UserModel.deleteMany({ phone: { $in: lidPhones } });
    return { deleted: result.deletedCount || 0, phones: lidPhones };
  } catch (e) { return { deleted: 0, error: e.message }; }
}

export async function getTopUploaders(limit = 10) {
  if (!dbReady) return [];
  try {
    return await UserModel.find({ uploadCount: { $gt: 0 } })
      .sort({ uploadCount: -1 })
      .limit(limit)
      .select('phone name school uploadCount referralCount plan')
      .lean();
  } catch (e) { return []; }
}

// Record when user first hits a daily limit (only sets once per day; cleared at daily reset)
export async function recordLimitExhaustion(phone, type) {
  if (!dbReady) return;
  const field = type === 'chat' ? 'exhaustedChatAt'
    : type === 'image' ? 'exhaustedImageAt'
    : type === 'pdf'   ? 'exhaustedPdfAt'
    : null;
  if (!field) return;
  try {
    // Only set if not already set (value is 0) — don't overwrite the original hit time
    await UserModel.updateOne({ phone, [field]: 0 }, { $set: { [field]: Date.now() } });
  } catch (_) {}
}

// Save / clear a pending referral code on a user record
export async function setPendingReferral(phone, code) {
  if (!dbReady || !phone) return;
  try {
    await UserModel.findOneAndUpdate(
      { phone },
      { $set: { pendingReferral: code || '' } },
      { upsert: true }
    );
  } catch (_) {}
}

export async function getPendingReferral(phone) {
  if (!dbReady || !phone) return '';
  try {
    const u = await UserModel.findOne({ phone }).select('pendingReferral').lean();
    return u?.pendingReferral || '';
  } catch (_) { return ''; }
}

// ─── Gift Code System (file-based) ────────────────────────────────────────────
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename2 = fileURLToPath(import.meta.url);
const __dirname2  = path.dirname(__filename2);
const GIFT_CODES_FILE = path.join(__dirname2, 'data', 'giftcodes.json');

function loadGiftCodes() {
  try {
    if (fs.existsSync(GIFT_CODES_FILE)) return JSON.parse(fs.readFileSync(GIFT_CODES_FILE, 'utf8'));
  } catch (_) {}
  return {};
}

function saveGiftCodes(codes) {
  try { fs.writeFileSync(GIFT_CODES_FILE, JSON.stringify(codes, null, 2), 'utf8'); } catch (_) {}
}

function randomCode(len = 8) {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < len; i++) code += chars[Math.floor(Math.random() * chars.length)];
  return code;
}

export function generateGiftCode(plan, customCode = null, maxUses = 1) {
  const validPlans = ['STARTER', 'BASIC', 'PRO', 'PREMIUM'];
  if (!validPlans.includes(plan.toUpperCase())) return null;
  const codes = loadGiftCodes();
  const code = (customCode || randomCode()).toUpperCase();
  const limit = (maxUses && maxUses > 0) ? maxUses : 1;
  codes[code] = {
    plan: plan.toUpperCase(),
    maxUses: limit,
    usedCount: 0,
    usedBy: [],
    createdAt: Date.now(),
  };
  saveGiftCodes(codes);
  return code;
}

export async function redeemGiftCode(code, phone) {
  const codes = loadGiftCodes();
  const entry = codes[code.toUpperCase()];
  if (!entry) return { ok: false, error: 'Invalid gift code. Please check and try again!' };
  const usedCount = entry.usedCount ?? (entry.used ? 1 : 0);
  const maxUses   = entry.maxUses ?? 1;
  if (usedCount >= maxUses) return { ok: false, error: 'This gift code has already been fully redeemed.' };
  const usedBy = Array.isArray(entry.usedBy) ? entry.usedBy : (entry.usedBy ? [entry.usedBy] : []);
  if (usedBy.includes(phone)) return { ok: false, error: 'You have already redeemed this gift code.' };
  entry.usedCount = usedCount + 1;
  entry.usedBy    = [...usedBy, phone];
  entry.used      = entry.usedCount >= maxUses;
  entry.usedAt    = Date.now();
  saveGiftCodes(codes);
  await activatePlan(phone, entry.plan);
  return { ok: true, plan: entry.plan };
}

export function listGiftCodes() {
  return loadGiftCodes();
}

// ─── Exam Question schema (RAG 2.0 — full ZIMSEC knowledge engine) ────────────
const examQuestionSchema = new mongoose.Schema({
  // ── Source metadata ───────────────────────────────────────────────────────
  sourceId:       { type: String, index: true },
  sourceCategory: { type: String, default: 'paper' },
  extractedFrom:  { type: String, default: '' },
  // ── Paper metadata ────────────────────────────────────────────────────────
  subject:        { type: String, required: true, index: true },
  level:          { type: String, required: true, index: true },
  grade:          { type: String, default: '' },
  year:           { type: String, default: '', index: true },
  session:        { type: String, default: '' },
  paperNum:       { type: String, default: '', index: true },
  pageNum:        { type: Number, default: 0 },
  // ── Question content ──────────────────────────────────────────────────────
  questionNum:    { type: Number, default: 0 },
  questionText:   { type: String, required: true },
  questionType:   { type: String, default: 'mcq', index: true }, // mcq|structured|essay|calculation|diagram
  optA:           { type: String, default: '' },
  optB:           { type: String, default: '' },
  optC:           { type: String, default: '' },
  optD:           { type: String, default: '' },
  answer:         { type: String, default: '' },
  explanation:    { type: String, default: '' },
  marks:          { type: Number, default: 1 },
  // ── Classification ────────────────────────────────────────────────────────
  topic:          { type: String, default: '', index: true },
  subtopic:       { type: String, default: '' },
  difficulty:     { type: String, default: 'medium', index: true }, // easy|medium|hard
  keywords:       { type: [String], default: [] },
  estimatedTime:  { type: Number, default: 90 },  // seconds
  // ── Image support ─────────────────────────────────────────────────────────
  imageUrl:       { type: String, default: '' },
  imageUrls:      { type: [String], default: [] },
  needsImage:     { type: Boolean, default: false },
  hasImage:       { type: Boolean, default: false },
  // ── OCR metadata ─────────────────────────────────────────────────────────
  ocrConfidence:  { type: Number, default: 100 },
  ocrEngine:      { type: String, default: 'pdf-parse' },
  // ── Duplicate tracking ────────────────────────────────────────────────────
  duplicateOf:    { type: String, default: '' },
  similarQuestions: { type: [String], default: [] },
}, { timestamps: true });

examQuestionSchema.index({ subject: 1, level: 1 });
examQuestionSchema.index({ subject: 1, level: 1, topic: 1 });
examQuestionSchema.index({ subject: 1, level: 1, year: 1 });
examQuestionSchema.index({ subject: 1, level: 1, difficulty: 1 });
examQuestionSchema.index({ subject: 1, level: 1, questionType: 1 });
examQuestionSchema.index({ sourceId: 1, questionNum: 1 });

export const ExamQuestionModel = mongoose.models.ExamQuestion || mongoose.model('ExamQuestion', examQuestionSchema);

// ─── Student Analytics schema ─────────────────────────────────────────────────
const examAnalyticsSchema = new mongoose.Schema({
  phone:          { type: String, required: true, index: true },
  subject:        { type: String, default: '' },
  level:          { type: String, default: '' },
  sessionId:      { type: String, default: '' },
  questionId:     { type: String, default: '' },
  questionType:   { type: String, default: 'mcq' },
  topic:          { type: String, default: '' },
  difficulty:     { type: String, default: 'medium' },
  userAnswer:     { type: String, default: '' },
  correctAnswer:  { type: String, default: '' },
  isCorrect:      { type: Boolean, default: false },
  marks:          { type: Number, default: 1 },
  earnedMarks:    { type: Number, default: 0 },
  timeTaken:      { type: Number, default: 0 },  // seconds
  year:           { type: String, default: '' },
  paperNum:       { type: String, default: '' },
}, { timestamps: true });

examAnalyticsSchema.index({ phone: 1, subject: 1 });
examAnalyticsSchema.index({ phone: 1, createdAt: -1 });

export const ExamAnalyticsModel = mongoose.models.ExamAnalytics || mongoose.model('ExamAnalytics', examAnalyticsSchema);

// ─── Save extracted questions (upsert to avoid duplicates) ────────────────────
export async function saveExtractedQuestions(questions) {
  if (!dbReady || !questions?.length) return 0;
  let saved = 0;
  try {
    for (const q of questions) {
      try {
        // Upsert: match on sourceId + questionNum to avoid duplicates on re-extraction
        if (q.sourceId && q.questionNum) {
          await ExamQuestionModel.findOneAndUpdate(
            { sourceId: q.sourceId, questionNum: q.questionNum },
            { $set: q },
            { upsert: true, new: true }
          );
        } else {
          await ExamQuestionModel.create(q);
        }
        saved++;
      } catch (_) {}
    }
  } catch (_) {}
  return saved;
}

// ─── Normalise a raw answer letter from AI/OCR output ─────────────────────────
function _normaliseAnswer(raw) {
  if (!raw) return '';
  // Extract just the first letter — handles "A.", "A)", "(A)", "a", "A " etc.
  const m = String(raw).trim().match(/^[(\s]*([A-Da-d])[.):\s]/i) || String(raw).trim().match(/^([A-Da-d])$/i);
  return m ? m[1].toUpperCase() : '';
}

// ─── Core question retrieval — ONLY from stored bank, never AI-generated ──────
export async function getExamQuestions(subject, level, { limit = 40, shuffle = true, topic = '', year = '', paperNum = '', difficulty = '', questionType = '' } = {}) {
  if (!dbReady) return [];
  try {
    const escapedSubject = subject.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const query = {
      subject: new RegExp(escapedSubject, 'i'),
      questionText: { $exists: true, $ne: '' },
    };
    if (level) query.level = level;
    if (topic) query.topic = new RegExp(topic.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
    if (year) query.year = year;
    if (paperNum) query.paperNum = paperNum;
    if (difficulty) query.difficulty = difficulty;
    if (questionType) query.questionType = questionType;
    const docs = await ExamQuestionModel.find(query).lean();
    if (!docs.length) return [];
    // Normalise answers in-memory so exam flow always gets clean A/B/C/D
    const normalised = docs.map(d => ({ ...d, answer: _normaliseAnswer(d.answer) }));
    const withAnswer = normalised.filter(d => ['A','B','C','D'].includes(d.answer));
    const pool = withAnswer.length > 0 ? withAnswer : normalised;
    if (shuffle) pool.sort(() => Math.random() - 0.5);
    return pool.slice(0, limit);
  } catch (e) { return []; }
}

// ─── Filtered question retrieval for practice mode ────────────────────────────
export async function getFilteredExamQuestions({ subject, level, topic, year, paperNum, difficulty, questionType, keyword, limit = 20, shuffle = true } = {}) {
  if (!dbReady) return [];
  try {
    const query = { questionText: { $exists: true, $ne: '' } };
    if (subject) {
      const esc = subject.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      query.subject = new RegExp(esc, 'i');
    }
    if (level) query.level = level;
    if (topic) query.topic = new RegExp(topic.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
    if (year) query.year = year;
    if (paperNum) query.paperNum = paperNum;
    if (difficulty) query.difficulty = difficulty;
    if (questionType) query.questionType = questionType;
    if (keyword) {
      const esc = keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      query.$or = [
        { questionText: new RegExp(esc, 'i') },
        { topic: new RegExp(esc, 'i') },
        { subject: new RegExp(esc, 'i') },
        { year: new RegExp(esc, 'i') },
      ];
    }
    const docs = await ExamQuestionModel.find(query).lean();
    if (!docs.length) return [];
    // Normalise answers in-memory
    const normalised = docs.map(d => ({ ...d, answer: _normaliseAnswer(d.answer) }));
    const withAnswer = normalised.filter(d => ['A','B','C','D'].includes(d.answer));
    const pool = withAnswer.length > 0 ? withAnswer : normalised;
    if (shuffle) pool.sort(() => Math.random() - 0.5);
    return pool.slice(0, limit);
  } catch (_) { return []; }
}

// ─── Count questions matching filters ─────────────────────────────────────────
export async function countExamQuestions(subject, level, { topic = '', year = '', difficulty = '' } = {}) {
  if (!dbReady) return 0;
  try {
    const escapedSubject = subject.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const query = { subject: new RegExp(escapedSubject, 'i') };
    if (level) query.level = level;
    if (topic) query.topic = new RegExp(topic.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
    if (year) query.year = year;
    if (difficulty) query.difficulty = difficulty;
    return await ExamQuestionModel.countDocuments(query);
  } catch (_) { return 0; }
}

// ─── Get distinct topics for a subject/level ──────────────────────────────────
export async function getExamTopics(subject, level) {
  if (!dbReady) return [];
  try {
    const esc = subject.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const filter = { subject: new RegExp(esc, 'i'), topic: { $ne: '' } };
    if (level) filter.level = level;
    const topics = await ExamQuestionModel.distinct('topic', filter);
    return topics.filter(Boolean).sort();
  } catch (_) { return []; }
}

// ─── Get distinct years for a subject/level ───────────────────────────────────
export async function getExamYears(subject, level) {
  if (!dbReady) return [];
  try {
    const esc = subject.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const filter = { subject: new RegExp(esc, 'i'), year: { $ne: '' } };
    if (level) filter.level = level;
    const years = await ExamQuestionModel.distinct('year', filter);
    return years.filter(Boolean).sort((a, b) => b.localeCompare(a));
  } catch (_) { return []; }
}

// ─── Get related questions (easier/similar/harder) ────────────────────────────
export async function getRelatedQuestions(questionId, subject, level, topic, difficulty) {
  if (!dbReady) return { easier: [], similar: [], harder: [] };
  try {
    const esc = subject.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const baseQuery = {
      level,
      subject: new RegExp(esc, 'i'),
      questionType: 'mcq',
      answer: { $in: ['A','B','C','D'] },
      _id: { $ne: questionId },
    };
    const topicQuery = topic ? { ...baseQuery, topic: new RegExp(topic.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i') } : baseQuery;
    const diffMap = { easy: ['easy'], medium: ['easy','medium'], hard: ['medium','hard'] };
    const easierDiffs = diffMap[difficulty] || ['easy'];
    const harderDiffs = difficulty === 'hard' ? ['hard'] : difficulty === 'medium' ? ['hard'] : ['medium','hard'];

    const [easier, similar, harder] = await Promise.all([
      ExamQuestionModel.find({ ...topicQuery, difficulty: { $in: easierDiffs } }).limit(3).lean(),
      ExamQuestionModel.find({ ...topicQuery, difficulty }).limit(3).lean(),
      ExamQuestionModel.find({ ...topicQuery, difficulty: { $in: harderDiffs } }).limit(3).lean(),
    ]);
    return { easier, similar, harder };
  } catch (_) { return { easier: [], similar: [], harder: [] }; }
}

// ─── Save exam attempt analytics ──────────────────────────────────────────────
export async function saveExamAttempt(data) {
  if (!dbReady) return null;
  try { return await ExamAnalyticsModel.create(data); } catch (_) { return null; }
}

// ─── Get student statistics ────────────────────────────────────────────────────
export async function getStudentStats(phone, subject = '', level = '') {
  if (!dbReady) return null;
  try {
    const query = { phone };
    if (subject) query.subject = subject;
    if (level) query.level = level;
    const attempts = await ExamAnalyticsModel.find(query).lean();
    if (!attempts.length) return null;
    const total      = attempts.length;
    const correct    = attempts.filter(a => a.isCorrect).length;
    const totalMarks = attempts.reduce((s, a) => s + (a.marks || 1), 0);
    const earnedMarks = attempts.reduce((s, a) => s + (a.earnedMarks || 0), 0);
    const accuracy   = total > 0 ? Math.round((correct / total) * 100) : 0;
    // Topic performance
    const topicMap = {};
    for (const a of attempts) {
      const t = a.topic || 'General';
      if (!topicMap[t]) topicMap[t] = { correct: 0, total: 0 };
      topicMap[t].total++;
      if (a.isCorrect) topicMap[t].correct++;
    }
    const topicStats = Object.entries(topicMap)
      .map(([topic, s]) => ({ topic, accuracy: Math.round((s.correct / s.total) * 100), total: s.total }))
      .sort((a, b) => a.accuracy - b.accuracy);
    const weakTopics   = topicStats.filter(t => t.accuracy < 50).slice(0, 5);
    const strongTopics = topicStats.filter(t => t.accuracy >= 70).sort((a, b) => b.accuracy - a.accuracy).slice(0, 5);
    return { total, correct, accuracy, totalMarks, earnedMarks, weakTopics, strongTopics, topicStats };
  } catch (_) { return null; }
}

// ─── Get bank summary (total questions per subject/level) ─────────────────────
export async function getExamBankSummary() {
  if (!dbReady) return [];
  try {
    return await ExamQuestionModel.aggregate([
      { $group: { _id: { subject: '$subject', level: '$level' }, count: { $sum: 1 }, years: { $addToSet: '$year' } } },
      { $sort: { '_id.level': 1, '_id.subject': 1 } },
    ]);
  } catch (_) { return []; }
}

export async function deleteExamQuestionsBySource(sourceId) {
  if (!dbReady) return;
  try { await ExamQuestionModel.deleteMany({ sourceId }); } catch (_) {}
}

export async function hasExtractedSource(sourceId) {
  if (!dbReady) return false;
  try { return (await ExamQuestionModel.countDocuments({ sourceId })) > 0; } catch (_) { return false; }
}

// Fast bulk check — returns Set of all sourceIds already in the question bank (1 query)
export async function getExtractedSourceIds() {
  if (!dbReady) return new Set();
  try {
    const ids = await ExamQuestionModel.distinct('sourceId');
    return new Set(ids.map(String));
  } catch (_) { return new Set(); }
}

export async function getAllApprovedMaterials({ level, category } = {}) {
  if (!dbReady) return [];
  try {
    const q = { approved: true, url: { $exists: true, $ne: '' } };
    if (level)    q.level    = level;
    if (category) q.category = category;
    return await MaterialModel.find(q).sort({ createdAt: -1 }).lean();
  } catch (_) { return []; }
}

// ─── Study Reminder schema ─────────────────────────────────────────────────────
const reminderSchema = new mongoose.Schema({
  phone:     { type: String, required: true, index: true },
  subject:   { type: String, default: '' },
  note:      { type: String, default: '' },
  remindAt:  { type: Number, required: true },  // ms epoch when to fire
  sent:      { type: Boolean, default: false },
}, { timestamps: true });

export const ReminderModel = mongoose.models.Reminder || mongoose.model('Reminder', reminderSchema);

export async function createReminder(phone, subject, note, remindAt) {
  if (!dbReady) return null;
  try { return await ReminderModel.create({ phone, subject, note, remindAt, sent: false }); } catch (e) { return null; }
}

export async function getUserReminders(phone) {
  if (!dbReady) return [];
  try {
    return await ReminderModel.find({ phone, sent: false, remindAt: { $gt: Date.now() } })
      .sort({ remindAt: 1 }).limit(20);
  } catch (e) { return []; }
}

export async function deleteReminder(id) {
  if (!dbReady) return false;
  try { await ReminderModel.findByIdAndDelete(id); return true; } catch (e) { return false; }
}

export async function getDueReminders() {
  if (!dbReady) return [];
  try {
    return await ReminderModel.find({ sent: false, remindAt: { $lte: Date.now() } }).limit(100);
  } catch (e) { return []; }
}

export async function markReminderSent(id) {
  if (!dbReady) return;
  try { await ReminderModel.findByIdAndUpdate(id, { sent: true }); } catch (_) {}
}
