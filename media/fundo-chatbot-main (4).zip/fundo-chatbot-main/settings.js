/**
 * ╔══════════════════════════════════════════╗
 * ║         FUNDO AI — Settings               ║
 * ║  WhatsApp Cloud API Configuration         ║
 * ╚══════════════════════════════════════════╝
 *
 * WABA_TOKEN       → Permanent or temporary access token from Meta Business Manager
 * PHONE_NUMBER_ID  → Phone Number ID (not the phone number itself) from Meta
 * WEBHOOK_VERIFY_TOKEN → Any secret string you choose for webhook verification
 * OWNER_NUMBER     → Your personal WhatsApp number (digits only, with country code)
 * BOT_PHONE        → The WhatsApp number the bot is registered on (digits only)
 * LOGO_URL         → Bot logo URL shown in menu messages
 * ADMIN_USERNAME / ADMIN_PASSWORD → Remote admin login credentials
 */

export default {
  WABA_TOKEN: process.env.WABA_TOKEN || "",
  PHONE_NUMBER_ID: process.env.PHONE_NUMBER_ID || "",
  WEBHOOK_VERIFY_TOKEN:
    process.env.WEBHOOK_VERIFY_TOKEN || "fundo_ai_webhook_secret",
  OWNER_NUMBER: process.env.OWNER_NUMBER || "263719647303",
  BOT_PHONE: process.env.BOT_PHONE || "263776046121",
  LOGO_URL:
    process.env.LOGO_URL ||
    "https://media.mrfrankofc.gleeze.com/media/funda.png",
  ADMIN_USERNAME: process.env.ADMIN_USERNAME || "mrfrankofc",
  ADMIN_PASSWORD: process.env.ADMIN_PASSWORD || "darex@123",
};
