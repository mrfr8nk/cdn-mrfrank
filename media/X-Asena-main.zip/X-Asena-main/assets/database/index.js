module.exports = {
  Notes: require("./notes"),
  Plugins: require("./plugins"),
  Filters: require("./filters"),
  Greetings: require("./greetings"),
  PausedChats:require("./PausedChat"),
  WarnDB:require('./warn')
};