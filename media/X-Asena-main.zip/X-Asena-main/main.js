const {command} = require("./lib")

module.exports = {Module:command}