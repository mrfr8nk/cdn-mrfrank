<!-- DO NOT CLONE MY PROPERTY LIKE LAST TIME - MR FRANK OFC-->

<h1 align="center"> 𝐒𝐔𝐁𝐙𝐄𝐑𝐎 𝐌𝐃 </h1>

<p align="center">
  <a href="https://github.com/mrfrankofcc/SUBZERO-MD">
    <img alt="SUBZERO-MD docs" height="350" src="https://files.catbox.moe/rzw7ng.jpg">
  </a>
</p>
    
</a>
</p>
<p align="center">
<a href="https://whatsapp.com/channel/0029VagQEmB002T7MWo3Sj1D"><img title="Author" src="https://img.shields.io/badge/SUBZERO-MD-darkgreen?style=for-the-badge&logo=whatsapp"></a>
<p/>

<p align="center">
    <strong>1. FORK REPOSITORY</strong>
  <br>
    <a href="https://github.com/mrfrankofcc/SUBZERO-MD/fork" target="_blank">
        <img alt="Fork Repo" src="https://img.shields.io/badge/Fork%20Repo-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=darkblue&color=darkblue"/>
    </a>
</p>

<p align="center">
    <strong>2. GET SESSION ID</strong>
    <br>
    <a href="https://subzero-id.onrender.com/" target="_blank">
        <img alt="WEBSITE" src="https://img.shields.io/badge/Pair-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=darkred&color=darkred"/>
    </a>
</p>

<center>
  
  ## 🚀 DEPLOYMENT OPTIONS 
</center>

<div align="center">
  <table>
    <tr>
      <td><a href="https://dashboard.heroku.com/new?template=https://github.com/mrfrankofcc/SUBZERO-MD/tree/main" target="_blank"><img src="https://img.shields.io/badge/Heroku-430098?style=for-the-badge&logo=heroku&logoColor=white&labelColor=000000&color=00ffff"/></a></td>
      <td><a href="https://talkdrove.com/share-bot/11" target="_blank"><img src="https://img.shields.io/badge/TalkDrove-6971FF?style=for-the-badge&logo=github&logoColor=white&labelColor=000000"/></a></td>
    </tr>
    <tr>
      <td><a href="https://app.koyeb.com/services/deploy?type=git&repository=mrfrankofcc/SUBZERO-MD" target="_blank"><img src="https://img.shields.io/badge/Koyeb-FF009D?style=for-the-badge&logo=koyeb&logoColor=white&labelColor=000000"/></a></td>
      <td><a href="https://railway.app/new" target="_blank"><img src="https://img.shields.io/badge/Railway-FF8700?style=for-the-badge&logo=railway&logoColor=white&labelColor=000000"/></a></td>
    </tr>
    <tr>
      <td><a href="https://dashboard.render.com/web/new" target="_blank"><img src="https://img.shields.io/badge/Render-000000?style=for-the-badge&logo=render&logoColor=white&labelColor=000000&color=00ffaa"/></a></td>
      <td><a href="https://app.netlify.com/" target="_blank"><img src="https://img.shields.io/badge/Netlify-CC00FF?style=for-the-badge&logo=huggingface&logoColor=white&labelColor=000000"/></a></td>
    </tr>
  </table>

  <td><a href="https://github.com/mrfrankofcc/SUBZERO-MD/archive/refs/heads/main.zip" target="_blank"><img src="https://img.shields.io/badge/Panel Zip-000000?style=for-the-badge&logo=bot-hosting&logoColor=white&labelColor=000000&color=blue"/></a></td>
</div>

<div align="center">
  <img src="https://github.com/mrfrankofcc/SUBZERO-MD/blob/main/assets/techwave.gif?raw=true" width="100%"/>
</div>
<center>
  
> `POWERED BY MR FRANK OFC 🇿🇼` </center>
